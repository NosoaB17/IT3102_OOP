/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;

/**
 *
 * @author ngsn1
 */
public class DiaNhac extends SanPham{
    private String Nhasanxuat;
    private String Casi;
    private String Bannhac;
    
    public String getNhaSanXuat(){
        return Nhasanxuat;
    }
    public void setNhaSanXuat(){
        this.Nhasanxuat=Nhasanxuat;
    }
    public String getCaSi(){
        return Casi;
    }
    public void setCaSi(String Casi){
        this.Casi=Casi;
    }
    public String getBanNhac(){
        return Bannhac;
    }
    public void setBanNhac(String Bannhac){
        this.Bannhac=Bannhac;
    }
    
}
