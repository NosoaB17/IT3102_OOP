/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ngsn1
 */
    public abstract class NhapKhoDAOlmpl implements NhapKhoDAO {
    List<NhapKho> nhapKhoList;   
    
    public NhapKhoDAOlmpl(){
        nhapKhoList = new ArrayList<>();
        NhapKho son = new NhapKho(1, "Sơn");
        NhapKho linh = new NhapKho(2, "Linh");
        NhapKho nghia = new NhapKho(3,"Nghĩa");
        NhapKho huy = new NhapKho(4,"Huy");
        NhapKho tham = new NhapKho(5,"Thắm");
        nhapKhoList.add(son);
        nhapKhoList.add(linh);
        nhapKhoList.add(nghia);
        nhapKhoList.add(huy);
        nhapKhoList.add(tham);        
    }
    
    @Override
    public List<NhapKho> showAllNhapKho() {
       return nhapKhoList;
    }

    @Override
    public NhapKho showNhapKhoByDate() {
       return nhapKhoList.get();
    }

    @Override
    public void addNhapKho(NhapKho k) {
        nhapKhoList.add(k);
        System.out.println(k.getName() + "Thêm thành công");
    }

    @Override
    public void updateNhapKho(NhapKho k) {
       nhapKhoList.get(k.getNhapKhoId()).setNhapKhoName(k.getName());
       System.out.println("Cập nhật thành công, tên nhân viên có Id:" + k.getNhapKhoId());
    }

    @Override
    public NhapKho findById(int Id) {
        return nhapKhoList.get(Id);
    }
        
    }

  
