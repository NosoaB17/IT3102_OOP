/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;
import java.util.List;
/**
 *
 * @author ngsn1
 */
public interface NhapKhoDAO {
    public List<NhapKho> showAllNhapKho();
    public List<NhapKho> showNhapKhoByDate();
    public void addNhapKho(NhapKho k);
    public void updateNhapKho(NhapKho k);
    public void findById(NhapKho k);
}
