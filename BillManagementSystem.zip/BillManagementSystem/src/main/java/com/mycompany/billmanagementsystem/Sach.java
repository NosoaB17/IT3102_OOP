/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;

/**
 *
 * @author ngsn1
 */
public class Sach extends SanPham{
    private String Nhaxuatban;
    private String Tacgia;
    private String Dichgia;
    
    public String getNhaXuatBan(){
        return Nhaxuatban;
    }
    public void setNhaXuatBan(String Nhaxuatban){
        this.Nhaxuatban=Nhaxuatban;
    }
    public String getTacGia(){
        return Tacgia;
    }
    public void setTacGia(String Tacgia){
        this.Tacgia=Tacgia;
    }
    public String getDichGia(){
        return Dichgia;
    }
    public void setDichGia(String Dichgia){
        this.Dichgia=Dichgia;
    }
}    
