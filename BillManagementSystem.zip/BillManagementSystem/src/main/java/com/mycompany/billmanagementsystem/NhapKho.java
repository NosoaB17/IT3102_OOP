/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;
import java.time.LocalDateTime;
/**
 *
 * @author ngsn1
 */
public class NhapKho  {

    NhapKho(int i, String sơn) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    NhapKho(double d) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int getNhapKhoId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setNhapKhoName(String name) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public class NhanVien{};
    public class SanPham{};
    public class NhaCungCap{};
    private int Id;
    private int Soluong;
    private int Gianhap;
    private int Thanhtien;
    private LocalDateTime Ngaynhap;
    
    public int getId(){
        return Id;
    }
    public void setId(int Id){
        this.Id=Id;
    }
    public int getSoLuong(){
        return Soluong;
    }
    public void setSoLuong(int Soluong){
        this.Soluong=Soluong;
    }
    public int getGiaNhap(){
        return Gianhap;
    }
    public void setGiaNhap(int Gianhap){
        this.Gianhap=Gianhap;
    }
    public int getThanhTien(){
        return Thanhtien;
    }
    public void setThanhTien(int Thanhtien){
        this.Thanhtien=Thanhtien;
    }
    public LocalDateTime getNgayNhap(){
        return Ngaynhap;
    }
    public void setNgayNhap(LocalDateTime Ngaynhap){
        this.Ngaynhap=Ngaynhap;
    }
}
