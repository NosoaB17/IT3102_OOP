/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;

/**
 *
 * @author ngsn1
 */
public class DiaPhim extends SanPham{
    private String Nhasanxuat;
    private String Daodien;
    
    public String getNhaSanXuat(){
        return Nhasanxuat;
    }
    public void setNhaSanXuat(String Nhasanxuat){
        this.Nhasanxuat=Nhasanxuat;
    }
    public String getDaoDien(){
        return Daodien;
    }
    public void setDaoDien(String Daodien){
        this.Daodien=Daodien;
    }
    
}
