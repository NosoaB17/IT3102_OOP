/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.billmanagementsystem;

/**
 *
 * @author ngsn1
 */
public class NhanVien {
    private int Id;
    private String Ten;
    private String Cccd;
    private String Sdt;
    private String Email;
    private String Taikhoan;
    private String Matkhau; 
    
    public int getId(){
        return Id;
    }
    public void setId(int Id){
        this.Id=Id;
    }
    public String getTen(){
        return Ten;
    }
    public void setTen(String Ten){
        this.Ten=Ten;
    }
    public String getCccd(){
        return Cccd;
    }
    public void setCccd(String Cccd){
        this.Cccd=Cccd;
    }
    public String getSdt(){
        return Sdt;
    }
    public void setSdt(String Sdt){
        this.Sdt=Sdt;
    }
    public String getEmail(){
        return Email;
    }
    public void setEmail(String Email){
        this.Email=Email;
    }
    public String getTaiKhoan(){
        return Taikhoan;
    }
    public void setTaiKhoan(String Taikhoan){
        this.Taikhoan=Taikhoan;
    }
    public String getMatKhau(){
        return Matkhau;
    }
    public void setMatKhau(String Matkhau){
        this.Matkhau=Matkhau;
    }
    
    
    
    
    
    
    
}
