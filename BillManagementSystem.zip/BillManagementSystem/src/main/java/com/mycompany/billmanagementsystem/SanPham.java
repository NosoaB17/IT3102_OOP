/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;
import java.time.LocalDateTime;
/**
 *
 * @author ngsn1
 */
public class SanPham {
    private int Id;
    private String Ten;
    private String Theloai;
    private int Soluong;
    private int Gianhap;
    private int Giaban;
    private LocalDateTime Ngaynhap;
    
    public int getId(){
        return Id;
    }
    public void setId(int Id){
        this.Id=Id;
    }
    public String getTen(){
        return Ten;
    }
    public void setTen(String Ten){
        this.Ten=Ten;
    }
    public String getTheLoai(){
        return Theloai;
    }
    public void setTheLoai(String Theloai){
        this.Theloai=Theloai;
    }
    public int getSoLuong(){
        return Soluong;
    }
    public void setSoLuong(int Soluong){
        this.Soluong=Soluong;
    }
    public int getGiaNhap(){
        return Gianhap;
    }
    public void setGiaNhap(int Gianhap){
        this.Gianhap=Gianhap;
    }
    public int getGiaBan(){
        return Giaban;
    }
    public void setGiaBan(int Giaban){
        this.Giaban=Giaban;
    }
    public LocalDateTime getNgayNhap(){
        return Ngaynhap;
    }
    public void setNgayNhap(LocalDateTime Ngaynhap){
        this.Ngaynhap=Ngaynhap;
    }
}



    
    
