/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.billmanagementsystem;

/**
 *
 * @author ngsn1
 */
public class NhaCungCap {
    private int Id;
    private String Ten;
    private String Sdt;
    private String Email;
    private String Diadiem;
    
    public int getId(){
        return Id;
    }
    public void setId(int Id){
        this.Id=Id;
    }
    public String getTen(){
        return Ten;
    }
    public void setTen(String Ten){
        this.Ten=Ten;
    }
    public String getSdt(){
        return Sdt;
    }
    public void setSdt(String Sdt){
        this.Sdt=Sdt;
    }
    public String getEmail(){
        return Email;
    }
    public void setEmail(String Email){
        this.Email=Email;
    }
    public String getDiaDiem(){
        return Diadiem;
    }
    public void setDiaDiem(String Diadiem){
        this.Diadiem=Diadiem;
    }
    
    
    
}
